% ELEC 4700 Assignment 1 Q1
% Liam Anderson 100941879
% Submission February 2 2020

global C

num_particles = 1000;

% using boundaries specified in assignment .pdf figure 2
boundaryX = 2e-7;
boundaryY = 1e-7;

% using constants from tjsssmy 4700 code
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability

Mass = C.m_0*0.26;
k = C.kb;
T = 300;
vth = sqrt(2*((k*T)/(Mass))); % thermal velocity
step = 1e-15;
timestep = 1000;
dv = step/vth;
t = 0;

% fixed initial velocities
for i=1:num_particles
    Vx(i) = vth*cos(2*pi*randn());
    Vy(i) = vth*sin(2*pi*randn());
end

% random initial positions
for i = 1:num_particles
    x(i) = rand()*boundaryX;
    y(i) = rand()*boundaryY;
end

while t < 1000*step % 1000 time steps
    
    x(1:num_particles) = x(1:num_particles) + (step .* Vx(1:num_particles));
    y(1:num_particles) = y(1:num_particles) + (step .* Vy(1:num_particles));
    
    t = t + step;
    
    for i=1:1:num_particles
       % angular reflection for y
       if y(i) >= boundaryY
           Vy(i) = - Vy(i);
       end
       if y(i) <= 0
           Vy(i) = - Vy(i);
       end
       % periodic boundary condition for x
       if x(i) <= 0
           x(i) = x(i) + boundaryX;
       end
       if x(i) >= boundaryX
           x(i) = x(i) - boundaryX;
       end
    end

    % trace some particles for plotting
    particlestotrace = 20;
    for i=1:1:particlestotrace
        colors = hsv(particlestotrace);
        plot(x(i),y(i), 'o', 'markers', 1, 'color', colors(i,:), 'MarkerFaceColor', colors(i,:));
    end
    
    % plot particle paths
    figure(1);
    title(['Q1 Electron Modelling   (' ,num2str(particlestotrace), ' electrons)']);
    axis([0 boundaryX 0 boundaryY]);
    hold on;
    pause(0.01);
    
end

%figure(2);
%axis([0 1000 0 500]);
%temp = (vth^2)*Mass/(2*k)
%for i=1:timestep
    %plot(i,temp);
%end
%hold on;
%pause(0.01);

