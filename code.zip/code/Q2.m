% ELEC 4700 Assignment 1 Q2
% Liam Anderson 100941879
% Submission February 2 2020

% ***** NOTE I couldn't figure out Maxwell-Boltzmann distribution so I
% used normal rand() distribution for initial velocities *****

% *** Exponential distribution for scattering as per assignment .pdf ***

global C

num_particles = 1000;

% using boundaries specified in assignment .pdf figure 2
boundaryX = 2e-7;
boundaryY = 1e-7;

% using constants from tjsssmy 4700 code
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability

Mass = C.m_0*0.26;
k = C.kb;
T = 300;
vth = sqrt(2*((k*T)/(Mass))); % thermal velocity
dt = 1e-15;
t = 0;
step_size = 1e-9;

% random initial velocities
for i=1:num_particles
    Vx(i) = (rand()*vth*10)*cos(2*pi*randn());
    Vy(i) = (rand()*vth*10)*sin(2*pi*randn());
end

% random initial positions
for i = 1:num_particles
    x(i) = rand()*boundaryX;
    y(i) = rand()*boundaryY;
end

while t < 500*dt % 500 time steps
    
    x(1:num_particles) = x(1:num_particles) + (dt .* Vx(1:num_particles));
    y(1:num_particles) = y(1:num_particles) + (dt .* Vy(1:num_particles));
    
    t = t + dt;
    
    %p_scat = [1 num_particle
    
    for i=1:1:num_particles
       % angular reflection for y
       if y(i) >= boundaryY || y(i) <= 0
           Vy(i) = - Vy(i);
       end
       % periodic boundary condition for x
       if x(i) <= 0
           x(i) = x(i) + boundaryX;
       end
       if x(i) >= boundaryX
           x(i) = x(i) - boundaryX;
       end
       % SCATTERING
       dv = step_size/vth;
       p_scat(i) = 1 - exp(-dv/0.2e-12);
       random(i) = rand();
       if p_scat(i) > random(i); % if scatter assign new random velocity
           Vx(i) = (rand()*vth*10)*cos(2*pi*randn());
           Vy(i) = (rand()*vth*10)*sin(2*pi*randn());
       end
    end
    


    % trace some particles for plotting
    particlestotrace = 10;
    for i=1:1:particlestotrace
        colors = hsv(particlestotrace);
        plot(x(i),y(i), 'o', 'markers', 1, 'color', colors(i,:), 'MarkerFaceColor', colors(i,:));
    end
    
    figure(1);
    title(['Q2 Collisions with MFP   (' ,num2str(particlestotrace), ' electrons)']);
    axis([0 boundaryX 0 boundaryY]);
    hold on;
    pause(0.01);
end