% ELEC 4700 Assignment 1 Q3
% Liam Anderson 100941879
% Submission February 2 2020

global C

num_particles = 1000;

% using boundaries specified in assignment .pdf figure 2
boundaryX = 2e-7;
boundaryY = 1e-7;

% using constants from tjsssmy 4700 code
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability

Mass = C.m_0*0.26;
k = C.kb;
T = 300;
vth = sqrt(2*((k*T)/(Mass))); % thermal velocity
dt = 1e-15;
t = 0;

% random initial velocities
for i=1:num_particles
    Vx(i) = (rand()*vth*10)*cos(2*pi*randn());
    Vy(i) = (rand()*vth*10)*sin(2*pi*randn());
end

% random initial positions
for i = 1:num_particles
    x(i) = rand()*boundaryX;
    y(i) = rand()*boundaryY;
    
    % INITIAL BOTTLENECK CHECK
    % Upper box (x-dimensions 0.8->1.2 and y-dimensions 0.6->1)
    if x(i) >= 0.6e-7 & x(i) <= 1.2e-7 & y(i) >= 0.6e-7
        x(i) = randi([1 6])/10e-7;
        y(i) = randi([1 10])/10e-7;
    end

    % Lower box (x-dimensions 0.8->1.2 and y-dimensions 0->0.4)
    if x(i) >= 0.6e-7 & x(i) <= 1.2e-7 & y(i) <= 0.4e-7
        x(i) = randi([1 6])/10e-7;
        y(i) = randi([1 10])/10e-7;
    end
    
    
end

    


while t < 1000*dt % 1000 time steps
    
    x(1:num_particles) = x(1:num_particles) + (dt .* Vx(1:num_particles));
    y(1:num_particles) = y(1:num_particles) + (dt .* Vy(1:num_particles));
    
    t = t + dt;
    
    for i=1:1:num_particles
       % angular reflection for y
       if y(i) >= boundaryY || y(i) <= 0
           Vy(i) = - Vy(i);
       end
       % periodic boundary condition for x
       if x(i) <= 0
           x(i) = x(i) + boundaryX;
       end
       if x(i) >= boundaryX
           x(i) = x(i) - boundaryX;
       end
       
       % BOTTLENECK CHECK
       % Upper box (x-dimensions 0.8->1.2 and y-dimensions 0.6->1)
       if x(i) >= 0.8e-7 && x(i) <= 1.2e-7 && y(i) >= 0.6e-7
           if y(i) > 0.6e-7 % collision with side of upper box
               Vx(i) = -Vx(i);
           end
           if y(i) == 0.6e-7 % collision with bottom of upper box
               Vy(i) = - Vy(i);
           end
       end

       % Lower box (x-dimensions 0.8->1.2 and y-dimensions 0->0.4)
       if x(i) >= 0.8e-7 && x(i) <= 1.2e-7 && y(i) <= 0.4e-7
           if y(i) < 0.4e-7 % collision with side of lower box
               Vx(i) = -Vx(i);
           end
           if y(i) == 0.4e-7 % collision with top of lower box
               Vy(i) = - Vy(i);
           end
       end       
       
       
    end
    
    
    % trace some particles for plotting
    particlestotrace = 10;
    for i=1:1:particlestotrace
        colors = hsv(particlestotrace);
        plot(x(i),y(i), 'o', 'markers', 1, 'color', colors(i,:), 'MarkerFaceColor', colors(i,:));
    end
    
    figure(1);
    title(['Q3 Enhancements   (' ,num2str(particlestotrace), ' electrons)']);
    axis([0 boundaryX 0 boundaryY]);
    rectangle('Position', [0.8e-7 0 0.4e-7 0.4e-7]);
    rectangle('Position', [0.8e-7 0.6e-7 0.4e-7 0.4e-7]);
    hold on;
    pause(0.01);
end